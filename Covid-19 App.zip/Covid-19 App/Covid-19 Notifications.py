import requests
import json
import plyer
import time
from datetime import date

while(1):
    r=requests.get("https://corona-rest-api.herokuapp.com/Api/uk/")
    info=r.text
    
    dict=json.loads(info)
    infodict=dict["Success"]
    
    tod=str(date.today())
    
    plyer.notification.notify(
        title= "Covid-19 Notification   "+tod,
        message= "Today's Cases: " +str(infodict["todayCases"]) + "\n" + "Today's Deaths: " +str(infodict["todayDeaths"]) + "\n" +"Total Cases: " +str(infodict["cases"]) + "\n" +  "Total Deaths: " +str(infodict["deaths"]),
        app_icon=r'/coronavirus.icns', timeout=7

)
    time.sleep(21600)
